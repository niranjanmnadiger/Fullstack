// Footer with personal links — built by Niranjan M Nadiger
import React from 'react';
import { Github, Linkedin, TrendingUp } from 'lucide-react';

const LINKS = [
  {
    icon: Github,
    label: 'GitHub',
    href: 'https://github.com/niranjanmnadiger',
    hoverColor: 'hover:text-white hover:bg-slate-700',
  },
  {
    icon: Linkedin,
    label: 'LinkedIn',
    href: 'https://www.linkedin.com/in/niranjan-m-nadiger/',
    hoverColor: 'hover:text-[#0A66C2] hover:bg-[#0A66C2]/10',
  },
];

export const Footer: React.FC = () => (
  <footer className="mt-12 border-t border-slate-800/60">
    <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 py-5">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">

        {/* Brand + byline */}
        <div className="flex items-center gap-2 text-slate-500 text-xs">
          <div className="w-5 h-5 rounded-md bg-indigo-500/20 flex items-center justify-center">
            <TrendingUp className="w-3 h-3 text-indigo-400" />
          </div>
          <span>
            FinFlow · Built by{' '}
            <span className="text-slate-400 font-medium">Niranjan M Nadiger</span>
          </span>
        </div>

        {/* Social links */}
        <div className="flex items-center gap-2">
          {LINKS.map(({ icon: Icon, label, href, hoverColor }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={label}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900 text-slate-400 text-xs font-medium transition-all duration-200 ${hoverColor} hover:border-slate-600`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{label}</span>
            </a>
          ))}
        </div>

      </div>
    </div>
  </footer>
);
